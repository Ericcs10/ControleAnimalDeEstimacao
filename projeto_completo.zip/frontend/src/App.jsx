import CadastroUsuario from './pages/CadastroUsuario';

function App() {
  return (
    <div className="App">
      <CadastroUsuario />
    </div>
  );
}

export default App;
